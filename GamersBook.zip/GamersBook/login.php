<!DOCTYPE html>
<html>
<head>
	<title>LOG IN</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="py-5">
		<h2 class="text-center">Please Login</h2>
	</div>
	<form action="verifylogin.php" method="POST">
	    <div class="w-50 m-auto">
    	<div class="form-group">
    <label >Name:</label>
    <input type="text" class="form-control" placeholder="Name" name="name">
  		</div>
  		<div class="w-80 ">
    	<div class="form-group">
    <label >Email address:</label>
    <input type="email" class="form-control" placeholder="Enter email" name="email">
  		</div>
  		<div class="w-50 ">
    	<div class="form-group">
    <label >Password:</label>
    <input type="text" class="form-control" placeholder="**************" name="password">
  		</div>
  		<div class="w-50 ">
      <div class="form-group">
    <label >Mobile:</label>
    <input type="tel" class="form-control"  placeholder="+8801*********" name="mobile">
      </div>
  		<button type="submit" class="btn btn-success">Log IN</button>
  		
  	</div>
  </div>
</form>
<form action="registration.php">
	<div class="w-50 py-5">
    	<div class="form-group">
  		<button type="submit" class="btn btn-success">Sign UP</button>
  	</div>
  </div>
  		</form>

</body>
</html>