<?php 
session_start();
$con= mysqli_connect('localhost','root');
if($con){
	echo "connection successfull";
}
else{
	echo "No connection";
}
mysqli_select_db($con, 'chat_system');
$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$password = $_POST['password'];


$query = "SELECT * FROM registration where name='$name' && password='$password' && email='$email' && mobile= '$mobile'";

$result = mysqli_query($con, $query);
$num = mysqli_num_rows($result);

if ($num== 1) {
	$_SESSION['username'] = $name;
	$_SESSION['usermail'] = $email;
	$_SESSION ['usermbl'] = $mobile;
	header('location:index.php');

}
else{
	echo "Wrong Inpts";
	header('location:login.php');
}

?>