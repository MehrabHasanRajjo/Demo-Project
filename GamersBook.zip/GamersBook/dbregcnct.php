<?php 
$con= mysqli_connect('localhost','root');
if($con){
	echo "connection successfull";
}
else{
	echo "No connection";
}
mysqli_select_db($con, 'gamerbookuserdata');
$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$password = $_POST['password'];

$query="insert into registration (name, email, mobile, password) values('$name', '$email', '$mobile', '$password')";

mysqli_query($con, $query);
header('location:login.php');

 ?>