<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">GamersBook</a>
  </form>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav m-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="profile.php">Review</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="news.php">News</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="editprofile.php">Profile</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0" action="logout.php">
      <button class="btn btn-outline-danger my-2 my-sm-0" type="submit">Logout</button>
    </form>
    <form action="searchresult.php" class="form-inline my-2 my-lg-0" method="get">
      <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search" name="keyword">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<section class="my-5 ma-auto">
	<div class="py=5">
    		<h2 class="text-center">Top reviews:</h2>
    		<div class="w-50 m-auto">
    		
    		<div class="card">
            <div class="card-body">
    	<?php
                $connection = mysqli_connect("localhost","root","");
                $db = mysqli_select_db($connection, 'gamerbookuserdata');

                $query = "SELECT * FROM userinfodata";
                $query_run = mysqli_query($connection, $query);
            ?>
                <table id="datatableid" class="table table-bordered table-dark">
                    <thead>
                        <tr>
                            <th scope="col"> ID</th>
                            <th scope="col">Email</th>
                            <th scope="col">Review</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
            <?php
                if($query_run)
                {
                    foreach($query_run as $row)
                    {
            ?>
                    <tbody>
                        <tr>
                            <td> <?php echo $row['id']; ?> </td>                            
                            <td> <?php echo $row['email']; ?> </td>                            
                            <td> <?php echo $row['review']; ?> </td>
                            <td> <a href="delete.php?id= <?php echo $row['id']; ?>">Delete</a></td>
                            <td> <a href="edit.php?id= <?php echo $row['id']; ?>">Edit</a></td>
                        </tr>
                    </tbody>
            <?php           
                    }
                }
                else 
                {
                    echo "No Record Found";
                }
            ?>
            </table>
            </div>
        </div>
	</div>
</div>

    	<div class="py=5">
    		<h2 class="text-center">Write a review:</h2>
    		
    	</div>
    	<div class="w-50 m-auto">
    		<form action="userinfo.php" method="post">
    	<div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" placeholder="Enter email" name="email">
  		</div>
  		<div class="form-group">
    <label>review:</label>
    <textarea class="form-control" name="review">
    	
    </textarea>
  </div>
  <button type="submit" class="btn btn-success">Submit</button>
    			
    		</form>
    	</div>

    	
    </section>



</body>
</html>