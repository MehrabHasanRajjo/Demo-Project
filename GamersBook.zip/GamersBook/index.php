<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Chat System</title>


	<link rel="stylesheet" href="style.css" type="text/css" />


	<script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>

</head>
<body>

	

	<div class="centeralised">

	

	
	<div class="chathistory">


	</div>

	<div class="chatbox">
		
		<form action="" method="POST">
			
			<textarea class="txtarea" id="message" name="message"></textarea>

		</form>

	</div>

	</div>


	

	<script>


		$(document).ready(function(){
			loadChat();
		});


		
		$('#message').keyup(function(e){


			var message = $(this).val();

			if( e.which == 13 ){

				$.post('handlers/ajax.php?action=SendMessage&message='+message, function(response){
					
					loadChat();
					$('#message').val('');

				});

			}

		});



		function loadChat()
		{
			$.post('handlers/ajax.php?action=getChat', function(response){
				
				$('.chathistory').html(response);

			});
		}


		setInterval(function(){
			loadChat();
		}, 100);

	</script>


</body>
</html>

<?php
session_start();
if (!isset($_SESSION['username'])) {
  header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>GamersBook-HOME</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">GamersBook</a>
  </form>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav m-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="editprofile.php">Profile</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="friends.php">Friends</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="notification.php">Notification</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="profile.php">Review</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="news.php">News</a>
      </li>
   
      
    </ul>
       <form action="search.php" class="form-inline my-2 my-lg-0" method="get">
      <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search" name="keyword">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
    <form class="form-inline my-2 my-lg-0" action="logout.php">
      <button class="btn btn-outline-danger my-2 my-sm-0" type="submit">Logout</button>
    </form>
  </div>
</nav>
<section class="my-5">
	<div class="py-5 m-auto">
		<h2 class="text-center">Happy Gaming :) </h2>
    
	</div>
  <div class="m-auto">
    <h2 class="text-center">Hi! <?php echo $_SESSION['username']; ?> Welcome Back</h2>
  </div>

	<div class="container-fluid">
	<div class="row">

	<div  class="col-lg-4 col-mg-4 col-12">
	<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/4.jpg">
  <div class="card-body">
    <h5 class="card-title">Turjo Hasan</h5>
    <p class="card-text">Loves to play CS go.Highly competitive player but also friendly.Looking for players to play with and to make new friends</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Rank:Gold Nova III</li>
    <li class="list-group-item">Age:22</li>
    <li class="list-group-item">Competitive</li>
  </ul>
  <div class="card-body">
    <a href="https://steamcommunity.com/profiles/76561198397147952/" class="card-link">Steam</a>
    <a href="https://discord.gg/Dy4JJH" class="card-link">Discord</a>
  </div>
</div>
</div>

<div  class="col-lg-4 col-mg-4 col-12">
	<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/5.jpg">
  <div class="card-body">
    <h5 class="card-title">Tanvir Mahmud</h5>
    <p class="card-text">Loves to play Rainbow six seige.Competitive player but also friendly.Looking for players to play with and to make new friends</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Rank:Gold III</li>
    <li class="list-group-item">Age:20</li>
    <li class="list-group-item">Friendly</li>
  </ul>
  <div class="card-body">
    <a href="https://steamcommunity.com/profiles/76561198397147952/" class="card-link">Steam</a>
    <a href="https://discord.gg/Dy4JJH" class="card-link">Discord</a>
  </div>
</div>
</div>

<div  class="col-lg-4 col-mg-4 col-12">
	<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/6.jpg">
  <div class="card-body">
    <h5 class="card-title">Mostafa Rafid</h5>
    <p class="card-text">Loves to play CS go.Friendly player plays for fun and good time.Looking for players to play with and to make new friends</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Rank:Gold Nova I</li>
    <li class="list-group-item">Age:18</li>
    <li class="list-group-item">Friendly</li>
  </ul>
  <div class="card-body">
    <a href="https://steamcommunity.com/profiles/76561198397147952/" class="card-link">Steam</a>
    <a href="https://discord.gg/Dy4JJH" class="card-link">Discord</a>
  </div>
</div>
</div>

<div  class="col-lg-4 col-mg-4 col-12">
	<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/7.jpg">
  <div class="card-body">
    <h5 class="card-title">Shihab Billah</h5>
    <p class="card-text">Loves to play fortnite.Competitive player but also friendly.Looking for players to play with and to make new friends</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Age:20</li>
    <li class="list-group-item">Competitive</li>
  </ul>
  <div class="card-body">
    <a href="https://www.epicgames.com/store/en-US/" class="card-link">Steam</a>
    <a href="https://discord.gg/Dy4JJH" class="card-link">Discord</a>
  </div>
</div>
</div>

<div  class="col-lg-4 col-mg-4 col-12">
	<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/8.jpg">
  <div class="card-body">
    <h5 class="card-title">Tawhidul Islam</h5>
    <p class="card-text">Loves to play Battlefield.Highly competitive player but also friendly.Looking for players to play with and to make new friends</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Age:22</li>
    <li class="list-group-item">Competitive</li>
  </ul>
  <div class="card-body">
    <a href="https://steamcommunity.com/profiles/76561198397147952/" class="card-link">Steam</a>
    <a href="https://discord.gg/Dy4JJH" class="card-link">Discord</a>
  </div>
</div>
</div>

<div  class="col-lg-4 col-mg-4 col-12">
	<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/9.jpg">
  <div class="card-body">
    <h5 class="card-title">Jim</h5>
    <p class="card-text">Loves to play Cod Warzone.Highly competitive player but also friendly.Looking for players to play with and to make new friends</p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">Age:22</li>
    <li class="list-group-item">Competitive</li>
  </ul>
  <div class="card-body">
    <a href="https://steamcommunity.com/profiles/76561198397147952/" class="card-link">Steam</a>
    <a href="https://discord.gg/Dy4JJH" class="card-link">Discord</a>
  </div>
</div>
</div>

    </div>
    </div>
</section>



</body>
</html>