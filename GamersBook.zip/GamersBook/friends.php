<?php
require "relation.php";
$uid = 1;
 
if (isset($_POST['req'])) {
  $pass = true;
  switch ($_POST['req']) {
    case "add": $pass = $REL->request($uid, $_POST['id']); break;
    case "accept": $pass = $REL->acceptReq($_POST['id'], $uid); break;
    case "cancel": $pass = $REL->cancelReq($uid, $_POST['id']); break;
    case "unfriend": $pass = $REL->unfriend($uid, $_POST['id'], false); break;
    case "block": $pass = $REL->block($uid, $_POST['id']); break;
    case "unblock": $pass = $REL->block($uid, $_POST['id'], false); break;
  }
  echo $pass ? "<div class='ok'>OK</div>" : "<div class='nok'>{$REL->error}</div>";
}
 
$users = $REL->getUsers(); ?>
<div id="userNow">You are now <?=$users[$uid]?>.</div>
<div id="userList"><?php
  $requests = $REL->getReq($uid);
  $friends = $REL->getFriends($uid);
  foreach ($users as $id=>$name) { if ($id != $uid) {
    echo "<div class='urow'>";
    echo "<div class='uname'>$id) $name</div>";
 
    if (isset($friends['b'][$id])) {
      echo "<button onclick=\"relate('unblock', $id)\">Unblock</button>";
    } else {
      echo "<button onclick=\"relate('block', $id)\">Block</button>";
    }
 
    if (isset($friends['f'][$id])) { 
      echo "<button onclick=\"relate('unfriend', $id)\">Unfriend</button>";
    }
    else if (isset($requests['in'][$id])) { 
      echo "<button onclick=\"relate('accept', $id)\">Accept Friend</button>";
    }
    else if (isset($requests['out'][$id])) { 
      echo "<button onclick=\"relate('cancel', $id)\">Cancel Add</button>";
    }
    else { 
      echo "<button onclick=\"relate('add', $id)\">Add Friend</button>";
    }
    echo "</div>";
  }}
?></div>
 
<form id="ninform" method="post" target="_self">
  <input type="hidden" name="req" id="ninreq"/>
  <input type="hidden" name="id" id="ninid"/>
</form>