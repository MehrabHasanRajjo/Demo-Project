<?php 
$con= mysqli_connect('localhost','root');
if($con){
	echo "connection successfull";
}
else{
	echo "No connection";
}
mysqli_select_db($con, 'gamerbookuserdata');
$email = $_POST['email'];
$review = $_POST['review'];

$query="insert into userinfodata (email, review) values('$email', '$review')";

mysqli_query($con, $query);
header('location:profile.php');

 ?>