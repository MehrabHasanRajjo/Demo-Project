<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">GamersBook</a>
  </form>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav m-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="profile.php">Review</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="news.php">News</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="editprofile.php">Profile</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0" action="logout.php">
      <button class="btn btn-outline-danger my-2 my-sm-0" type="submit">Logout</button>
    </form>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<section>
<div class="py=5">
    		<h2 class="text-center">Write a review:</h2>
    		
    	</div>
    	<div class="w-50 m-auto">
    		<form action="" method="post">
    			<?php 
$con= mysqli_connect('localhost','root');
$db = mysqli_select_db($con, 'gamerbookuserdata');

$id = $_GET['id'];
$selectquery = "select * from userinfodata where id=$id";
$query=mysqli_query($con, $selectquery);

$result = mysqli_fetch_assoc($query);

if (isset($_POST['submit'])) {
$email = $_POST['email'];
$review = $_POST['review'];

$updatequery="update userinfodata set id=$id, email = '$email', review= '$review' where id=$id";
$query = mysqli_query($con, $updatequery);

header('location:profile.php');
}



 ?>
    	<div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" placeholder="Enter email" name="email" value="<?php echo $result['email'] ?>">
  		</div>
  		<div class="form-group">
    <label>review:</label>
    <textarea class="form-control" name="review">
    	<?php echo $result['review'] ?>
    </textarea>
  </div>
  <button type="submit" class="btn btn-success" name="submit">Edit</button>
    			
    		</form>
    	</div>
    </section>
</body>
</html>