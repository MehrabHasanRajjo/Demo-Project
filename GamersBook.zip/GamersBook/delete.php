<?php
      $con = mysqli_connect("localhost","root");
   	mysqli_select_db($con, 'gamerbookuserdata');
   	$id = $_GET['id'];
   	$deletequery = "delete from userinfodata where id=$id";
   	$query= mysqli_query($con,$deletequery);
   	header('location:profile.php');

?>